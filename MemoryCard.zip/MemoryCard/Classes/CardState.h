//
//  CardState.h
//  MemoryCard
//
//  Created by JasonWu on 11/24/14.
//
//

#ifndef MemoryCard_CardState_h
#define MemoryCard_CardState_h

enum class CardState{
    FRONT,  //正面
    BACK    //背面
};

#endif
