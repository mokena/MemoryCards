//
//  UserData.h
//  MemoryCard
//
//  Created by JasonWu on 12/12/14.
//
//

#ifndef MemoryCard_UserData_h
#define MemoryCard_UserData_h

static const char NEW_SCORE[]="NewScore";
static const char RANK_SCORE[]="RankScore";
#endif
