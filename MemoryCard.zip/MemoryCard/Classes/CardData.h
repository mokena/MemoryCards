//
//  CardData.h
//  MemoryCard
//
//  Created by JasonWu on 11/25/14.
//
//

#ifndef MemoryCard_CardData_h
#define MemoryCard_CardData_h

struct CardData{
    int flipCount;
    int number;
    int row;
    int column;
};



#endif
