//
//  ScoreData.h
//  MemoryCard
//
//  Created by JasonWu on 12/2/14.
//
//

#ifndef MemoryCard_ScoreData_h
#define MemoryCard_ScoreData_h

struct ScoreData
{
    int score;//分数
    int maxContinuous;//最大连击数
    int energy;//能量
};

#endif
