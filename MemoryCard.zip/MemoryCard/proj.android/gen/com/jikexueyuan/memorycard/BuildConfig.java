/** Automatically generated file. DO NOT MODIFY */
package com.jikexueyuan.memorycard;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}